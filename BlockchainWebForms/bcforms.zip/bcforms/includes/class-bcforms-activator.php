<?php

/**
 * Fired during plugin activation
 *
 * @link       https://www.linkedin.com/in/ciprianamariei/
 * @since      1.0.0
 *
 * @package    Bcforms
 * @subpackage Bcforms/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Bcforms
 * @subpackage Bcforms/includes
 * @author     Ciprian Amariei <ciprian.amariei@gmail.com>
 */
class Bcforms_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {

	}

}
