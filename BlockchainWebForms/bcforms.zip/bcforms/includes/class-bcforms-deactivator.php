<?php

/**
 * Fired during plugin deactivation
 *
 * @link       https://www.linkedin.com/in/ciprianamariei/
 * @since      1.0.0
 *
 * @package    Bcforms
 * @subpackage Bcforms/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Bcforms
 * @subpackage Bcforms/includes
 * @author     Ciprian Amariei <ciprian.amariei@gmail.com>
 */
class Bcforms_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

	}

}
